<?php
// Before removing this file, please verify the PHP ini setting `auto_prepend_file` does not point to this.

if (file_exists('/homepages/33/d620636396/htdocs/refurbs/dev/wp-content/plugins/wordfence/waf/bootstrap.php')) {
	define("WFWAF_LOG_PATH", '/homepages/33/d620636396/htdocs/refurbs/dev/wp-content/wflogs/');
	include_once '/homepages/33/d620636396/htdocs/refurbs/dev/wp-content/plugins/wordfence/waf/bootstrap.php';
}
?>